/**
*@author created by 穆洪桥
*@date 2017年7月10日---下午10:47:38
*@problem
*@answer
*@action
*/

package 端口扫描器;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class testmysql {
	public static void main(String[] args){
		String url = "jdbc:mysql://localhost:3306/mytest?useUnicode=true&characterEncoding=utf8";    
	    String user = "root";    
	    String psw = "root";            
	    try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("找不到驱动程序类 ，加载驱动失败！");
			e.printStackTrace();
		}
	    try {
			Connection con = DriverManager.getConnection(url,user,psw) ;
			Statement stmt = con.createStatement();
			String sql = "select * from port where id='80'";
			ResultSet result = stmt.executeQuery(sql);
			while(result.next()){
				System.out.println(result.getString("id"));
				System.out.println(result.getString("des"));
				
			}
			stmt.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("数据库连接失败！");
			e.printStackTrace();
		}
	}
}

