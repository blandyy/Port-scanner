/**
*@author created by 穆洪桥
*@date 2017年7月10日---下午8:59:19
*@problem
*@answer
*@action
*/

package 端口扫描器;

import java.io.*;
import java.util.ArrayList;

public class ttttest {

	public static void main(String[] args) {
		/**  
		*使用文件输出流构造一个对象输出流  
		*FileOutputStream文件输出流  
		*ObjectOutputStream对象输出流  
		*/   
		ArrayList<String> arr=new ArrayList<String>();
//		arr.add("sss");
//		arr.add("lll");
//		arr.add("ddd");
//		ObjectOutputStream out;
//		try {
//			out = new ObjectOutputStream(new   
//			FileOutputStream("D:/ee.txt"));
//			out.writeObject(arr); 
//			out.close(); 
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}   
		ObjectInputStream in;
		try {
			in = new ObjectInputStream(new FileInputStream("D:/ee.txt"));
			arr = (ArrayList<String>) in.readObject();   
			in.close();
			for(int i=0;i<arr.size();i++){
				System.out.println(arr.get(i));
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}   
				///readObject()将对象从"employee.dat"中读出，需要类型转换   
 catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				   
	}
}

